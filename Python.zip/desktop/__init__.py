__all__ = ['meridium', 'run_desktop', ]

from network.sockets_client import SocketsClient